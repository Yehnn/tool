i = 0
while i<30_000_000 # while loop 1
  i += 1
  a = b = c = d = e = f = g = h = j = k = l = m = n = o = p = q = r = 1
end
