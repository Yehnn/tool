5000000.times { 42.quo(3) }
